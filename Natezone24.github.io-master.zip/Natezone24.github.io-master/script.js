function free(){
  document.write(alert('Installing Free Bitcoin real not virus money $$$$$$$$') + alert(Math.random() + ' Bitcoin.') + alert("Sending to your account...") + alert('Verifying...') + alert('Auto Human verification failed.') + alert('Please go to this site.') + alert('https://bit.ly/3lC23dR'))
}
function gc(){
  window.location.href="GeicoInsurance.html";
}
function nfts(){
  window.location.href="nfts.html";
}
function back(){
  window.location.href="index.html";
}
function life(){
  window.location.href="lifeinsurance.html"
}
function politics(){
  window.location.href='politics.html'
}
function fungames(){
  window.location.href='fungames.html'
}
function economy(){
  window.location.href='economy.html'
}
function Health(){
  window.location.href='Elderlyhealth.html'
}